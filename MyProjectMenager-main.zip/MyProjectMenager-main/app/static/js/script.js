// script.js

// Log a message to the console when the script is loaded
console.log("JavaScript file loaded successfully.");

// Example function to show an alert when a button is clicked
// function showAlert() {
//     alert("Button clicked!");
// }

// // Add event listeners to buttons if needed
// document.addEventListener("DOMContentLoaded", function() {
//     const buttons = document.querySelectorAll("button");
//     buttons.forEach(button => {
//         button.addEventListener("click", showAlert);
//     });
// });